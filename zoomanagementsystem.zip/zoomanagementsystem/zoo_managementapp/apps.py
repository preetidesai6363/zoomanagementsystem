from django.apps import AppConfig


class ZooManagementappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'zoo_managementapp'
