from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('customerlogin',views.customerlogin,name='customerlogin'),
    path('customerreg',views.customerreg,name='customerreg'),
    path('addfeedback',views.addfeedback,name='addfeedback'),
    path('viewzoohistory',views.viewzoohistory,name='viewzoohistory')
]