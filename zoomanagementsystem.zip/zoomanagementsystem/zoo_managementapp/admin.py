from django.contrib import admin
from .models import workers,categories

admin.site.register(workers)
admin.site.register(categories)

# Register your models here.
