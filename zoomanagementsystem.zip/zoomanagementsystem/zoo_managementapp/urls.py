from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('adminlogin',views.adminlogin, name='adminlogin'),
    path('addworkers',views.addworkers,name='addworkers'),
    path('viewworkers',views.viewworkers,name='viewworkers'),
    path('viewfeedback',views.viewfeedback,name='viewfeedback'),

    path('workerlogin',views.workerlogin,name='workerlogin'),
    path('addcategorie',views.addcategorie,name='addcategorie'),
    path('viewlist',views.viewlist,name='viewlist'),
    path('viewcostomerfeedback',views.viewcostomerfeedback,name='viewcostomerfeedback'),
    path('updatecategory/<int:id>',views.updatecategory,name='updatecategory'),
    path('deletecategory/<int:id>',views.deletecategory,name='deletecategory'),
    path('modifycategory',views.modifycategory,name='modifycategory'),
    path('addmap',views.addmap,name='addmap',)
]