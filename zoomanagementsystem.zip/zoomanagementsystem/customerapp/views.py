from django.shortcuts import render,redirect
from .models import customers,feedbacks
from django.contrib import messages
from zoo_managementapp.models import categories


# Create your views here.
customerhomepage = "customerhome.html"
customerloginpage = "customerlogin.html"
customerregistration = "cregistartion.html"
addfeedbackandrating ="addfeedback.html"
zoohistorys ="viewzoohistory.html"

#home page
def index(request):
    return render(request,"index.html")

#customer login
def customerlogin(request):
    if request.method == "POST":
        customeremail = request.POST['customeremail']
        password = request.POST['password']
        print(customeremail,password)
        dc = customers.objects.filter(customeremail=customeremail,password=password).exists()
        if dc:
            request.session['customeremail'] = customeremail
            dc = customers.objects.filter(customeremail=customeremail,password=password)
            print(dc)
            x = []
            for i in dc:
                x.append(i.customeremail)
            print(x)
            request.session['customeremail']=x[0]
            dc = customers.objects.filter(customeremail=customeremail,password=password)
            return render(request,customerhomepage, {'dc':dc,'customeremail':customeremail})
        else:
            try:
                messages.add_message(request, messages.INFO, 'Credentials are not valid')
                return redirect("customerlogin")
            except:
                pass
    return render(request,customerloginpage)


#customer registration
def customerreg(request):
    if request.method == "POST":
        customername =request.POST['customername']
        customeremail = request.POST['customeremail']
        password = request.POST['password']
        conformpassword = request.POST['conformpassword']
        customercontact = request.POST['customercontact']
        customeraddress = request.POST['customeraddress']
        if password == conformpassword:
            dc = customers(customername=customername,customeremail=customeremail,password=password,customercontact=customercontact,customeraddress=customeraddress)
            dc.save()
            return customerlogin(request)
        else:
            messages.add_message(request, messages.INFO, 'Account already exists with these credentials')
            return render(request,customerregistration)

    return render(request,customerregistration)

#add feedback and rating
def addfeedback(request):
    dc = customers.objects.filter(customeremail=request.session['customeremail'])
    newdata = []
    for i in dc:
        newdata.append([i.customername,i.customercontact])
    all_details = newdata
    print(all_details)
    name= all_details[0][0]
    contact = all_details[0][1]
    email = request.session['customeremail']
    print(name)
    if request.method == "POST":
        rating = request.POST['rating']
        feedback = request.POST['message']
        customername = request.POST['username']
        customeremail = request.POST['useremail']
        customercontact = request.POST['contact']
        print(rating)
        dc = feedbacks(reating=rating,feedback=feedback,customername=customername,customeremail=customeremail,customercontact=customercontact)
        dc.save()
        messages.add_message(request, messages.INFO, 'Details added successfully')
        return render(request,addfeedbackandrating,{'name':name,'email':email,'contact':contact})
    else:
        messages.add_message(request, messages.INFO, 'Details added successfully')
        return render(request,addfeedbackandrating,{'name':name,'email':email,'contact':contact})
    


#view zoo history
def viewzoohistory(request):
    zoohistory = categories.objects.all()
    return render(request, zoohistorys,{'zoohistory' : zoohistory})

        



            
        