from django.shortcuts import render,redirect
from django.contrib import messages
from .models import workers,categories
from customerapp.models import feedbacks

# Create your views here.

homepage = "index.html"
adminhomepage = "adminhome.html"
adminloginpage ="adminlogin.html"
workersadd ="workers.html"
viewworker = "viewworker.html"
workerhome ="workershome.html"
workerloginpage ="workerlogin.html"
addcategories = "addcategories.html"
viewalllists = "viewlists.html"
viewrating = "viewrating.html"
customerfeedbacks ="viewcustomerfeedback.html"
updatepage = "updatepage.html"
addmaps ="addmap.html"


#index page
def index(request):
    return render(request,homepage)

#adminlogin 
def adminlogin(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['pwd']
        if email == "admin@gmail.com" and password == "admin":
            return render(request, adminhomepage)
        messages.info(request, "invalid details")
        return render(request,adminloginpage)
    return render(request,adminloginpage)

#worker login
def workerlogin(request):
     if request.method == "POST":
        workeremail = request.POST['email']
        password = request.POST['pwd']
        print(workeremail,password)
        dc = workers.objects.filter(workeremail=workeremail,password=password).exists()
        if dc:
            dc = workers.objects.filter(workeremail=workeremail,password=password)
            print(dc)
            x = []
            for i in dc:
                x.append(i.workeremail)
            print(x)
            request.session['workeremail']=x[0]
            print(request.session['workeremail'])
            request.session['workeremail'] = workeremail
            print(request.session['workeremail'])
            dc = workers.objects.filter(workeremail=workeremail,password=password)
            return render(request,workerhome, {'dc':dc,'workeremail':workeremail})
        else:
            try:
                messages.add_message(request, messages.INFO, 'Credentials are not valid')
                return redirect("workerlogin")
            except:
                pass
     return render(request,workerloginpage)

#add workers
def addworkers(request):
    if request.method == "POST":
        workerid = request.POST['workerid']
        workername=request.POST['workername']
        workeremail=request.POST['workeremail']
        password=request.POST['password']
        workercontact =request.POST['workercontact']
        workeraddress = request.POST['workeraddress']
        data = workers(workerid=workerid, workername =workername,workeremail= workeremail, password=password,workercontact=workercontact,workeraddress=workeraddress)
        data.save()
        print(data)
        return render(request,workersadd)
    else:
        messages.add_message(request, messages.INFO, 'Account already exists with these credentials')
        return render(request,workersadd)

#view workers
def viewworkers(request):
    print(request.session['workeremail'])
    workerdata = workers.objects.filter(workeremail=request.session['workeremail'])
    return render(request,viewworker,{'workerdata':workerdata})

#view feedback
def viewfeedback(request):
    feedback = feedbacks.objects.filter(customeremail=request.session['customeremail'])
    return render(request, viewrating ,{'feedback' : feedback})

#add categories
def addcategorie(request):
    if request.method == 'POST':
        placename = request.POST['placename']
        filedata = request.FILES['filedata']
        dc = categories(placename=placename,filedata=filedata)
        dc.save()
        messages.add_message(request,messages.INFO,'Details added successfully')
        return render(request,addcategories)
    return render(request,addcategories)

#view categories list
def viewlist(request):
   listdata = categories.objects.filter()
   return render(request, viewalllists,{'listdata':listdata})

#update categories
def updatecategory(request,id):
    print(id)
    return render(request,updatepage,{'id':id})

#modified categories
def modifycategory(request):
    if request.method =="POST":
        id = request.POST['id']
        placename = request.POST['placename']
        filedata = request.FILES['filedata']
        update_date = categories.objects.get(id=id)
        update_date.placename = placename
        update_date.filedata = filedata
        update_date.save()
    return redirect('viewlist')

#delete the categories data
def deletecategory(request,id):
    categories.objects.filter(id=id).delete()
    return redirect("viewlist")


#view feedback 
def viewcostomerfeedback(request):
    customerfoodback =feedbacks.objects.filter(customeremail=request.session['customeremail'])
    return render(request, customerfeedbacks ,{'customerfoodback' : customerfoodback})

#add map
def addmap(request):
    return render(request, addmaps)




