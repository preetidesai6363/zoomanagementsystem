from django.db import models

# Create your models here.


class workers(models.Model):
    workerid = models.CharField(max_length=50,null=True)
    workername = models.CharField(max_length=100,null=True)
    workeremail = models.CharField(max_length=100,null=True)
    password = models.CharField(max_length=100,null=True)
    workercontact = models.CharField(max_length=100,null=True)
    workeraddress = models.CharField(max_length=100,null=True)

class categories(models.Model):
    placeid = models.CharField(max_length=100)
    placename = models.CharField(max_length=100,null=True)
    filedata = models.FileField(upload_to="static/images")

    
    
