from django.db import models

# Create your models here.

class customers(models.Model):
    customername = models.CharField(max_length=100)
    customeremail = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    customercontact = models.CharField(max_length=100)
    customeraddress = models.CharField(max_length=100)

class feedbacks(models.Model):
    reating = models.CharField(max_length=100)
    feedback = models.CharField(max_length=100)
    customername =models.CharField(max_length=100, null=True)
    customeremail = models.EmailField(max_length=100,null=True)
    customercontact = models.CharField(max_length=100,null=True)



